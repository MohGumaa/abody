Social Media Resources - sample file for development.
